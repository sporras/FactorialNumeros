package sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class SocketServer {

    public static void main(String args[]) throws IOException {

        BufferedReader entrada = null;
        PrintWriter salida = null;

        Scanner recibe=new Scanner(System.in);
       
        int puerto = 0;
        

        System.out.println("Ingresa el puerto receptor");
        puerto=recibe.nextInt();
        
        Socket socket = null;
        //se crea una instanci500a de ServerSocket que estara atendiendo en el puerto 1234
        ServerSocket serverSocket = new ServerSocket(puerto);
        System.out.println("Esperando conexion de cliente en el puerto"+puerto);
        
        while (true) {
            try {
                //el ServerSocket da el acceso Socket al cliente que lo solicito
                socket = serverSocket.accept();
                
                //se obtiene informacion(IP) del cliente
                System.out.println("Conexion establecida desde la IP: " + socket.getInetAddress());
                
               //obtengo la entrada y la salida de bytes 
               entrada = new BufferedReader( new InputStreamReader(socket.getInputStream()));
               salida = new PrintWriter( new OutputStreamWriter(socket.getOutputStream()), true);
               //leo el nombre que envia el cliente
               String nombreCliente = entrada.readLine();
               
                double resultado=1;
                
                for (double i = 1; i <= Double.parseDouble(nombreCliente); i++) {
                    resultado *= i;
                }
                
               //regreso un saludo como respuesta al cliente
                String saludoServer = "Resultado " + resultado + "!!";
                salida.println(saludoServer);
                socket.close();

            } catch (IOException e) {
                System.out.println(e);
            }
        }
    }
}
